package com.payment.model;

import java.sql.Date;

public class Payment {
long paymentNumber;
public long getPaymentNumber() {
	return paymentNumber;
}
public void setPaymentNumber(long paymentNumber) {
	this.paymentNumber = paymentNumber;
}
public long getAmount() {
	return amount;
}
public void setAmount(long amount) {
	this.amount = amount;
}
public Date getDate() {
	return date;
}
public void setDate(Date date) {
	this.date = date;
}
long amount;
Date date;
}
