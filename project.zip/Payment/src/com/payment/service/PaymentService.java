package com.payment.service;

import java.sql.SQLException;
import java.util.List;


import com.payment.database.DBCon;
import com.payment.model.Payment;

public class PaymentService {

	List<Payment> getSort1(List<Payment> payment) {
		for (int i = 0; i < payment.size(); i++) {
			for (int j = i + 1; j < payment.size(); j++) {
				if(payment.get(j).getPaymentNumber()>payment.get(i).getPaymentNumber()){
					Payment pmt = new Payment();
					pmt.setPaymentNumber(payment.get(j).getPaymentNumber());
					pmt.setAmount(payment.get(j).getAmount());
					pmt.setDate(payment.get(j).getDate());
					payment.get(j).setPaymentNumber(payment.get(i).getPaymentNumber());
					payment.get(j).setAmount(payment.get(i).getAmount());
					payment.get(j).setDate(payment.get(i).getDate());
					payment.get(i).setPaymentNumber(pmt.getPaymentNumber());
					payment.get(i).setAmount(pmt.getAmount());
					payment.get(i).setDate(pmt.getDate());
				}
			}
		}
		return payment;
	}
	
	List<Payment> getSort2(List<Payment> payment) {
	        int n = payment.size(); 
	        for (int i = 1; i < n; ++i) { 
	            Payment key = new Payment();
	            key.setPaymentNumber(payment.get(i).getPaymentNumber());
	            key.setAmount(payment.get(i).getAmount());
	            key.setDate(payment.get(i).getDate());
	            int j = i - 1; 
	  
	            while (j >= 0 && payment.get(j).getPaymentNumber() < key.getPaymentNumber()) { 
					payment.get(j+1).setPaymentNumber(payment.get(j).getPaymentNumber());
					payment.get(j+1).setAmount(payment.get(j).getAmount());
					payment.get(j+1).setDate(payment.get(j).getDate());				 
	                j = j - 1; 
	            } 
	            payment.get(j+1).setPaymentNumber(key.getPaymentNumber());
				payment.get(j+1).setAmount(key.getAmount());
				payment.get(j+1).setDate(key.getDate());    
	        } 
	    return payment;
	}

	public static void main(String[] args) throws SQLException {

		PaymentService paymentService = new PaymentService();
		DBCon dbCon = new DBCon();
		List<Payment> payment = dbCon.getData();
		if (payment.isEmpty()) {
			dbCon.insertData();
		}
		else{
			List<Payment> payment1 = paymentService.getSort1(payment);
			System.out.println(payment1);
			List<Payment> payment2 = paymentService.getSort2(payment);
			System.out.println(payment2);
		}

	}
}
