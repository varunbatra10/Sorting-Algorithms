package com.payment.database;

import java.sql.Connection;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;
import java.sql.Date;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.sql.Timestamp;
import com.payment.model.*;

public class DBCon {
	Connection con = null;

	public Connection getConnection() throws SQLException {
		try {
			if (con == null) {
				Class.forName("com.mysql.jdbc.Driver");
				con = DriverManager.getConnection("jdbc:mysql://localhost:3306/test", "root", "root");
			}
			return con;
		} catch (Exception e) {
			System.out.println(e);
			return con;
		}
	}

	public void insertData() throws SQLException {
		if (con == null) {
			con = getConnection();
		} 
			Date date = new Date(Calendar.getInstance().getTime().getTime());
			PreparedStatement ps = con.prepareStatement("Insert into payment values(?,?,?)");
			for (int i = 1; i <= 1000; i++) {
				ps.setLong(1, i);
				ps.setLong(2, i * 100);
				ps.setDate(3, date);
				ps.addBatch();
			}
			ps.executeBatch();
			
	}
	
	public List<Payment> getData() throws SQLException{
		List<Payment> payment = new ArrayList<>();
		if (con == null) {
			con = getConnection();
		} 
		Statement stmt = con.createStatement();
		ResultSet rs = stmt.executeQuery("Select * from payment");
		while(rs.next()){
			Payment pmt = new Payment();
			pmt.setPaymentNumber(rs.getLong("paymentNumber"));
			pmt.setAmount(rs.getLong("amount"));
			pmt.setDate(rs.getDate("date"));
			payment.add(pmt);
		}
		return payment;
	}

}